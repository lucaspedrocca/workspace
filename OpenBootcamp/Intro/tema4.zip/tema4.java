package com.company;
class Main {

    public static void main(String[] args) {
        
        // Ejercicio 1
        int numeroIf = 0;

        if (numeroIf < 0){
            System.out.println("El número ingresado es negativo.");
        }
        else if(numeroIf > 0){
            System.out.println("El número ingresado es positivo.");
        } else {
            System.out.println("El número ingresado es 0");
        }

        // Ejercicio 2
        int numeroWhile = 1;

        while(numeroWhile < 3){
            numeroWhile++;
            System.out.println("numeroWhile ahora vale: " + numeroWhile);
        }

        // Ejercicio 3
        int numeroDoWhile = 3;
        do{
            numeroDoWhile++;
            System.out.println(" numeroDoWhile ahora vale: " + numeroDoWhile);
        }while(numeroDoWhile < 3);

        // Ejercicio 4
        for(int numeroFor = 0; numeroFor <= 3; numeroFor++){
            System.out.println("La variable numeroFor ahora vale: " + numeroFor);
        }

        // Ejercicio 5
        String estacion = "otoño";
        switch(estacion) {
            case "verano":
                System.out.println("Estamos en verano");
                break;
            case "invierno":
                System.out.println("Estamos en invierno");
                break;
            case "primavera":
                System.out.println("Estamos en primavera");
                break;
            case "otoño":
                System.out.println("Estamos en otoño");
                break;
            default:
                System.out.println("No es una estación");
        }
    }
}
